﻿namespace Clubbing.Forme
{
    partial class FormaPregledSvihDogadjaja
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.BtnRezerviraj = new System.Windows.Forms.Button();
            this.BtnGalerijaDogadjaja = new System.Windows.Forms.Button();
            this.BtnPovratak = new System.Windows.Forms.Button();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.BtnOtvoriKlub = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gainsboro;
            this.label1.Location = new System.Drawing.Point(49, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Svi događaji";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(53, 73);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(710, 168);
            this.dataGridView1.TabIndex = 1;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.ForeColor = System.Drawing.Color.Gainsboro;
            this.radioButton2.Location = new System.Drawing.Point(581, 28);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(99, 21);
            this.radioButton2.TabIndex = 12;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Nadolazeći";
            this.radioButton2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.ForeColor = System.Drawing.Color.Gainsboro;
            this.radioButton1.Location = new System.Drawing.Point(404, 28);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(84, 21);
            this.radioButton1.TabIndex = 11;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Završeni";
            this.radioButton1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // BtnRezerviraj
            // 
            this.BtnRezerviraj.ForeColor = System.Drawing.Color.Black;
            this.BtnRezerviraj.Location = new System.Drawing.Point(245, 276);
            this.BtnRezerviraj.Name = "BtnRezerviraj";
            this.BtnRezerviraj.Size = new System.Drawing.Size(122, 40);
            this.BtnRezerviraj.TabIndex = 13;
            this.BtnRezerviraj.Text = "Rezerviraj";
            this.BtnRezerviraj.UseVisualStyleBackColor = true;
            this.BtnRezerviraj.Click += new System.EventHandler(this.BtnRezerviraj_Click);
            // 
            // BtnGalerijaDogadjaja
            // 
            this.BtnGalerijaDogadjaja.ForeColor = System.Drawing.Color.Black;
            this.BtnGalerijaDogadjaja.Location = new System.Drawing.Point(463, 276);
            this.BtnGalerijaDogadjaja.Name = "BtnGalerijaDogadjaja";
            this.BtnGalerijaDogadjaja.Size = new System.Drawing.Size(152, 40);
            this.BtnGalerijaDogadjaja.TabIndex = 14;
            this.BtnGalerijaDogadjaja.Text = "Prikaži galeriju";
            this.BtnGalerijaDogadjaja.UseVisualStyleBackColor = true;
            this.BtnGalerijaDogadjaja.Click += new System.EventHandler(this.BtnGalerijaDogadjaja_Click);
            // 
            // BtnPovratak
            // 
            this.BtnPovratak.ForeColor = System.Drawing.Color.Black;
            this.BtnPovratak.Location = new System.Drawing.Point(53, 347);
            this.BtnPovratak.Name = "BtnPovratak";
            this.BtnPovratak.Size = new System.Drawing.Size(122, 40);
            this.BtnPovratak.TabIndex = 15;
            this.BtnPovratak.Text = "Nazad";
            this.BtnPovratak.UseVisualStyleBackColor = true;
            this.BtnPovratak.Click += new System.EventHandler(this.BtnPovratak_Click);
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.ForeColor = System.Drawing.Color.Gainsboro;
            this.radioButton3.Location = new System.Drawing.Point(245, 27);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(48, 21);
            this.radioButton3.TabIndex = 16;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "Svi";
            this.radioButton3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // BtnOtvoriKlub
            // 
            this.BtnOtvoriKlub.ForeColor = System.Drawing.Color.Black;
            this.BtnOtvoriKlub.Location = new System.Drawing.Point(641, 347);
            this.BtnOtvoriKlub.Name = "BtnOtvoriKlub";
            this.BtnOtvoriKlub.Size = new System.Drawing.Size(122, 40);
            this.BtnOtvoriKlub.TabIndex = 17;
            this.BtnOtvoriKlub.Text = "Otvori klub";
            this.BtnOtvoriKlub.UseVisualStyleBackColor = true;
            this.BtnOtvoriKlub.Click += new System.EventHandler(this.BtnOtvoriKlub_Click);
            // 
            // FormaPregledSvihDogadjaja
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.ClientSize = new System.Drawing.Size(800, 399);
            this.Controls.Add(this.BtnOtvoriKlub);
            this.Controls.Add(this.radioButton3);
            this.Controls.Add(this.BtnPovratak);
            this.Controls.Add(this.BtnGalerijaDogadjaja);
            this.Controls.Add(this.BtnRezerviraj);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label1);
            this.ForeColor = System.Drawing.Color.Black;
            this.Name = "FormaPregledSvihDogadjaja";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormaPregledSvihDogadjaja";
            this.Load += new System.EventHandler(this.FormaPregledSvihDogadjaja_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Button BtnRezerviraj;
        private System.Windows.Forms.Button BtnGalerijaDogadjaja;
        private System.Windows.Forms.Button BtnPovratak;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.Button BtnOtvoriKlub;
    }
}